#MDC com JUnit

#### numeros pares e impares MDC
#### implementar as propriedades 2 a 7.
